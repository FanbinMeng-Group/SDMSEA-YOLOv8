ultralytics-main/ultralytics/yolo/utils/ops.py      

Searching ----------, unraveling the comments of the original statement can turn off Soft-NMS