from ultralytics import YOLO


model = YOLO("YOLOv8.yaml")
# model = YOLO('')



model.train(data="VisDrone.yaml",seed=1,epochs=150,pretrained=True,batch=1,device='0',iou=0.7,
            imgsz=640,weight_decay=0.0005,patience=20,workspace=32)


# ,resume='runs/detect/mx/weights/last.pt'


