---
description: Train faster with mixed precision. Learn how to use BaseTrainer with Advanced Mixed Precision to optimize YOLOv3 and YOLOv4 models.
---

# BaseTrainer
---
:::ultralytics.yolo.engine.trainer.BaseTrainer
<br><br>

# check_amp
---
:::ultralytics.yolo.engine.trainer.check_amp
<br><br>
