---
description: Train a custom image classification model using Ultralytics YOLOv8 with ClassificationTrainer. Boost accuracy and efficiency today.
---

# ClassificationTrainer
---
:::ultralytics.yolo.v8.classify.train.ClassificationTrainer
<br><br>

# train
---
:::ultralytics.yolo.v8.classify.train.train
<br><br>
