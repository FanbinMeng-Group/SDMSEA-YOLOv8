---
description: Learn how to use auto_annotate in Ultralytics YOLO to generate annotations automatically for your dataset. Simplify object detection workflows.
---

# auto_annotate
---
:::ultralytics.yolo.data.annotator.auto_annotate
<br><br>
