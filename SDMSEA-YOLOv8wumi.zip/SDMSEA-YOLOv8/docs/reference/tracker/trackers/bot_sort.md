---
description: '"Optimize tracking with Ultralytics BOTrack. Easily sort and track bots with BOTSORT. Streamline data collection for improved performance."'
---

# BOTrack
---
:::ultralytics.tracker.trackers.bot_sort.BOTrack
<br><br>

# BOTSORT
---
:::ultralytics.tracker.trackers.bot_sort.BOTSORT
<br><br>
