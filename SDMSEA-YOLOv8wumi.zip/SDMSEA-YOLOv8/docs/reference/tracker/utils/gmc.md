---
description: '"Track Google Marketing Campaigns in GMC with Ultralytics Tracker. Learn to set up and use GMC for detailed analytics. Get started now."'
---

# GMC
---
:::ultralytics.tracker.utils.gmc.GMC
<br><br>
